import mongoose, { Schema, Document } from 'mongoose';
import { AIChatMessage } from '../../src/types/index.js';

export interface IConversationDocument extends Document {
  userId: string;
  title: string;
  messages: AIChatMessage[];
  updatedAt: string;
}

const ConversationSchema = new Schema<IConversationDocument>(
  {
    userId: { type: String, required: true, index: true },
    title: { type: String, required: true },
    messages: [
      {
        id: { type: String, required: true },
        sender: { type: String, enum: ['user', 'assistant', 'system'], required: true },
        content: { type: String, required: true },
        codeSnippet: { type: String },
        language: { type: String },
        components: [{ type: String }],
        timestamp: { type: String, required: true }
      }
    ],
    updatedAt: { type: String, default: () => new Date().toISOString() }
  },
  {
    timestamps: true
  }
);

export const ConversationModel =
  mongoose.models.Conversation || mongoose.model<IConversationDocument>('Conversation', ConversationSchema);
