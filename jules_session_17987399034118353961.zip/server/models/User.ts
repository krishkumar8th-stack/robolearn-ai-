import mongoose, { Schema, Document } from 'mongoose';
import { User as IUser } from '../../src/types/index.js';

export interface IUserDocument extends Omit<IUser, 'id'>, Document {
  passwordHash: string;
}

const UserSchema = new Schema<IUserDocument>(
  {
    fullName: { type: String, required: true },
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ['user', 'admin'], default: 'user' },
    experienceLevel: { type: String, enum: ['Beginner', 'Intermediate', 'Advanced'], default: 'Beginner' },
    preferredLanguage: { type: String, default: 'en' },
    preferredProgrammingLanguage: { type: String, default: 'cpp' },
    xp: { type: Number, default: 0 },
    level: { type: Number, default: 1 },
    streak: { type: Number, default: 1 },
    lastActiveDate: { type: String, default: () => new Date().toISOString() },
    completedLessons: [{ type: String }],
    completedChallenges: [{ type: String }],
    completedProjects: [{ type: String }],
    learnedComponents: [{ type: String }],
    achievements: [{ type: String }]
  },
  {
    timestamps: true
  }
);

export const UserModel = mongoose.models.User || mongoose.model<IUserDocument>('User', UserSchema);
