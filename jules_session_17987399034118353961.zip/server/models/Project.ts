import mongoose, { Schema, Document } from 'mongoose';
import { RoboticsProject as IRoboticsProject } from '../../src/types/index.js';

export interface IProjectDocument extends Omit<IRoboticsProject, 'id'>, Document {
  userId?: string;
  isCustom?: boolean;
}

const ProjectSchema = new Schema<IProjectDocument>(
  {
    title: { type: String, required: true },
    tagline: { type: String, required: true },
    difficulty: { type: String, enum: ['Beginner', 'Intermediate', 'Advanced'], default: 'Beginner' },
    category: { type: String, required: true },
    imageUrl: { type: String },
    estimatedHours: { type: Number, default: 2 },
    xpReward: { type: Number, default: 100 },
    prerequisites: [{ type: String }],
    componentsRequired: [{ type: String }],
    circuitOverview: { type: String, required: true },
    theory: { type: String, required: true },
    steps: [
      {
        stepNumber: { type: Number, required: true },
        title: { type: String, required: true },
        description: { type: String, required: true },
        imageUrl: { type: String },
        codeSnippet: { type: String },
        circuitNote: { type: String }
      }
    ],
    completeCode: { type: String, required: true },
    programmingLanguage: { type: String, default: 'cpp' },
    simulationConfig: {
      components: [{ type: String }],
      initialObstacleDistance: { type: Number, default: 30 }
    },
    userId: { type: String },
    isCustom: { type: Boolean, default: false }
  },
  {
    timestamps: true
  }
);

export const ProjectModel = mongoose.models.Project || mongoose.model<IProjectDocument>('Project', ProjectSchema);
