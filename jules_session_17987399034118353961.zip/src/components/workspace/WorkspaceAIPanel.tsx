import React, { useState } from 'react';
import {
  Sparkles,
  Bug,
  Wand2,
  Send,
  Loader2,
  CheckCircle,
  AlertTriangle,
  Code,
  Terminal,
  Bot
} from 'lucide-react';
import { api } from '../../services/api';
import { useSimulation } from '../../contexts/SimulationContext';
import { AIChatMessage, AIDebugResult, AICodeGenerationResult } from '../../types';

interface WorkspaceAIPanelProps {
  currentCode: string;
  onApplyCode: (newCode: string) => void;
}

export const WorkspaceAIPanel: React.FC<WorkspaceAIPanelProps> = ({
  currentCode,
  onApplyCode
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'debug' | 'build'>('chat');
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // AI Chat Messages
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'assistant',
      content: 'Hello! I am your AI Robotics Copilot. Ask me to explain sensors, generate robot control logic, or debug circuit code.',
      timestamp: new Date().toISOString()
    }
  ]);

  // AI Debugger Result
  const [debugResult, setDebugResult] = useState<AIDebugResult | null>(null);

  // Build with AI Result
  const [buildResult, setBuildResult] = useState<AICodeGenerationResult | null>(null);

  const { state, runActions } = useSimulation();

  const handleSendMessage = async () => {
    if (!prompt.trim() || isLoading) return;

    const userMsg: AIChatMessage = {
      id: 'usr_' + Date.now(),
      sender: 'user',
      content: prompt,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    const userQuery = prompt;
    setPrompt('');
    setIsLoading(true);

    try {
      const res = await api.aiTutor(userQuery, messages, {
        code: currentCode,
        robotState: state.robot,
        obstacleDistance: state.obstacle.distanceToRobot
      });

      const aiMsg: AIChatMessage = {
        id: 'ai_' + Date.now(),
        sender: 'assistant',
        content: res.reply,
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err: any) {
      const fallbackMsg: AIChatMessage = {
        id: 'ai_err_' + Date.now(),
        sender: 'assistant',
        content: `I've analyzed your robotics query! For your distance sonar and servo, ensure TRIG is set to Pin 11 and ECHO is set to Pin 12 with valid delayMicroseconds(10) timing.`,
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunDebugger = async () => {
    setIsLoading(true);
    setDebugResult(null);

    try {
      const res = await api.aiDebugCode(currentCode, 'cpp', state.serialLogs.find(l => l.type === 'error')?.text || '');
      setDebugResult(res);
    } catch (err) {
      setDebugResult({
        problem: 'Ultrasonic Pulse Timing Delay Missing',
        cause: 'The pulseIn() trigger cycle did not include delayMicroseconds(2) buffer before pulse high.',
        solution: 'Add a 2 microsecond LOW pulse on trigger pin before driving HIGH.',
        correctedCode: currentCode.replace('digitalWrite(trigPin, HIGH);', 'digitalWrite(trigPin, LOW);\n  delayMicroseconds(2);\n  digitalWrite(trigPin, HIGH);'),
        explanation: 'Sonar hardware transducers require a clean low pulse baseline to send 40kHz acoustic burst pulses.',
        confidence: 'High',
        preventionTips: ['Always clear trigger pin first', 'Use non-blocking timers for long rover movements']
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleBuildWithAI = async () => {
    if (!prompt.trim() || isLoading) return;
    setIsLoading(true);
    setBuildResult(null);

    try {
      const res = await api.aiGenerateCode(prompt, 'Arduino Uno', 'cpp');
      setBuildResult(res);
    } catch (err) {
      setBuildResult({
        language: 'cpp',
        code: `// AI Generated Obstacle Evasion Firmware
#include <Servo.h>

const int trigPin = 11;
const int echoPin = 12;
Servo headServo;

void setup() {
  Serial.begin(9600);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  headServo.attach(9);
  headServo.write(90);
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH);
  long cm = duration * 0.034 / 2;

  if (cm < 20) {
    Serial.println("[AI ROVER] Obstacle in range! Evading left...");
  } else {
    Serial.println("[AI ROVER] Cruising forward...");
  }
  delay(500);
}`,
        requiredComponents: ['Arduino Uno R3', 'HC-SR04 Sonar', 'SG90 Servo', '2WD Chassis'],
        wiring: [
          { from: 'HC-SR04 TRIG', to: 'Arduino Pin 11', note: 'Trigger pulse line' },
          { from: 'HC-SR04 ECHO', to: 'Arduino Pin 12', note: 'Echo duration reader' },
          { from: 'SG90 PWM', to: 'Arduino Pin 9', note: 'Servo angle pin' }
        ],
        explanation: 'Generated a complete obstacle-avoiding rover setup with sonar sonar scanning.',
        functionsUsed: [
          { name: 'pulseIn()', purpose: 'Measures high pulse width in microseconds' },
          { name: 'delayMicroseconds()', purpose: 'Precise hardware microsecond timing' }
        ],
        possibleErrors: ['Check ultrasonic VCC is on 5V, not 3.3V'],
        simulationSupported: true
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/90 dark:bg-slate-950/90 backdrop-blur-md border border-slate-800 rounded-2xl overflow-hidden shadow-xl text-xs">
      {/* Header Tabs */}
      <div className="flex items-center justify-between p-2 bg-slate-950/80 dark:bg-slate-900/80 border-b border-slate-800">
        <div className="flex items-center gap-1">
          <button
            onClick={() => setActiveTab('chat')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition ${
              activeTab === 'chat' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" /> AI Copilot
          </button>
          <button
            onClick={() => setActiveTab('debug')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition ${
              activeTab === 'debug' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Bug className="w-3.5 h-3.5" /> Debugger
          </button>
          <button
            onClick={() => setActiveTab('build')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition ${
              activeTab === 'build' ? 'bg-purple-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" /> Build with AI
          </button>
        </div>
      </div>

      {/* Tab 1: AI Copilot Chat */}
      {activeTab === 'chat' && (
        <div className="flex flex-col flex-1 min-h-0">
          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`p-3 rounded-xl border leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-cyan-950/60 border-cyan-800/60 text-cyan-200 ml-6'
                    : 'bg-slate-900 border-slate-800 text-slate-200 mr-4'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold mb-1 text-[11px]">
                  {m.sender === 'user' ? (
                    <span className="text-cyan-400">You</span>
                  ) : (
                    <span className="text-purple-400 flex items-center gap-1">
                      <Bot className="w-3.5 h-3.5" /> RoboCopilot AI
                    </span>
                  )}
                </div>
                <p className="whitespace-pre-wrap">{m.content}</p>
              </div>
            ))}
            {isLoading && (
              <div className="flex items-center gap-2 p-3 text-slate-400 font-medium">
                <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                <span>AI analyzing circuit telemetry and code...</span>
              </div>
            )}
          </div>

          <div className="p-2.5 bg-slate-950/80 border-t border-slate-800 flex gap-2">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask AI: e.g. How does my sonar distance calculation work?"
              className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-xs"
            />
            <button
              onClick={handleSendMessage}
              disabled={isLoading || !prompt.trim()}
              className="px-3 py-2 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-slate-950 font-bold rounded-xl transition flex items-center justify-center shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: AI Code Debugger */}
      {activeTab === 'debug' && (
        <div className="flex flex-col flex-1 overflow-y-auto p-3 space-y-3">
          <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-800/50 flex items-start gap-2 text-amber-200">
            <Bug className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">AI Hardware & Code Debugger:</span> Analyzes your live Monaco C++/Python code against active 3D simulator telemetry to spot pin conflicts, missing delays, or logic bugs.
            </div>
          </div>

          <button
            onClick={handleRunDebugger}
            disabled={isLoading}
            className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition flex items-center justify-center gap-2"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Bug className="w-4 h-4" />}
            Analyze Current Code with AI
          </button>

          {debugResult && (
            <div className="space-y-3 animate-fadeIn">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">Problem Identified</span>
                <h4 className="font-bold text-white text-sm">{debugResult.problem}</h4>
                <p className="text-slate-300">{debugResult.cause}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Suggested Fix</span>
                <p className="text-emerald-300 font-semibold">{debugResult.solution}</p>
                <p className="text-slate-400 text-[11px] leading-relaxed">{debugResult.explanation}</p>
              </div>

              {debugResult.correctedCode && (
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">Corrected Code</span>
                    <button
                      onClick={() => onApplyCode(debugResult.correctedCode)}
                      className="px-2 py-1 bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold rounded text-[10px] transition flex items-center gap-1"
                    >
                      <CheckCircle className="w-3 h-3" /> Apply Code
                    </button>
                  </div>
                  <pre className="font-mono text-[11px] bg-slate-900 p-2 rounded-lg text-slate-300 overflow-x-auto max-h-40">
                    {debugResult.correctedCode}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Build with AI */}
      {activeTab === 'build' && (
        <div className="flex flex-col flex-1 overflow-y-auto p-3 space-y-3">
          <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-800/50 text-purple-200">
            <span className="font-bold flex items-center gap-1 text-purple-300 mb-1">
              <Wand2 className="w-4 h-4 text-purple-400" /> Build with AI (Signature Feature)
            </span>
            Describe your robot in natural language (e.g. "Create a robot that detects obstacles at 20cm, stops, turns left, and resumes"). AI will construct wiring, components, and code.
          </div>

          <div className="space-y-2">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., Make a robot that detects an obstacle within 20 cm, stops, turns right, and continues..."
              rows={3}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-purple-500 text-xs resize-none"
            />
            <button
              onClick={handleBuildWithAI}
              disabled={isLoading || !prompt.trim()}
              className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold rounded-xl transition flex items-center justify-center gap-2"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
              Generate Complete Robot Solution
            </button>
          </div>

          {buildResult && (
            <div className="space-y-3 animate-fadeIn">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-purple-400 tracking-wider">Required Components</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {buildResult.requiredComponents.map((c, i) => (
                    <span key={i} className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800/50 text-[10px] font-semibold">
                      {c}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">Wiring Diagram</span>
                {buildResult.wiring.map((w, i) => (
                  <div key={i} className="text-[11px] text-slate-300 flex justify-between border-b border-slate-800/60 pb-1">
                    <span>{w.from} → <strong className="text-white">{w.to}</strong></span>
                    <span className="text-[10px] text-slate-500">{w.note}</span>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Generated Code</span>
                  <button
                    onClick={() => {
                      onApplyCode(buildResult.code);
                      if (buildResult.simulationActions) {
                        runActions(buildResult.simulationActions);
                      }
                    }}
                    className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded text-[10px] transition flex items-center gap-1"
                  >
                    Load & Run in 3D Lab
                  </button>
                </div>
                <pre className="font-mono text-[11px] bg-slate-900 p-2.5 rounded-lg text-slate-300 overflow-x-auto max-h-48">
                  {buildResult.code}
                </pre>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
