import React, { useState } from 'react';
import {
  Bot,
  Cpu,
  Radio,
  Settings2,
  Plug,
  Plus,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Info
} from 'lucide-react';

interface SidebarCategory {
  id: string;
  label: string;
  icon: React.ReactNode;
  items: { id: string; name: string; icon: string; desc: string; type: string }[];
}

const SIDEBAR_CATEGORIES: SidebarCategory[] = [
  {
    id: 'robots',
    label: 'Robots',
    icon: <Bot className="w-4 h-4 text-cyan-400" />,
    items: [
      { id: 'rover', name: 'Rover 2WD / 4WD', icon: '🏎️', desc: 'Differential drive mobile robot with sonar turret', type: 'robot-chassis' },
      { id: 'line_follower', name: 'Line Follower', icon: '🤖', desc: 'Dual IR sensors for line tracking', type: 'robot-chassis' },
      { id: 'robotic_arm', name: '3-DOF Servo Arm', icon: '🦾', desc: 'Triple servo mechanical gripper arm', type: 'servo' },
      { id: 'custom_robot', name: 'Custom Rover Chassis', icon: '⚙️', desc: 'Customizable robotics base', type: 'robot-chassis' }
    ]
  },
  {
    id: 'electronics',
    label: 'Electronics',
    icon: <Cpu className="w-4 h-4 text-amber-400" />,
    items: [
      { id: 'arduino-uno', name: 'Arduino Uno R3', icon: '🎛️', desc: 'ATmega328P 16MHz Microcontroller', type: 'arduino-uno' },
      { id: 'esp32', name: 'ESP32 NodeMCU', icon: '📶', desc: 'Dual-core 240MHz Wi-Fi + BLE Board', type: 'esp32' },
      { id: 'breadboard', name: 'Breadboard', icon: '🔲', desc: '830 Point Solderless Prototyping Board', type: 'breadboard' },
      { id: 'resistor', name: 'Resistor 220Ω', icon: '➖', desc: 'Current limiting resistor', type: 'resistor' }
    ]
  },
  {
    id: 'sensors',
    label: 'Sensors',
    icon: <Radio className="w-4 h-4 text-emerald-400" />,
    items: [
      { id: 'ultrasonic', name: 'HC-SR04 Sonar', icon: '📡', desc: '2cm - 400cm Ultrasonic Distance Sensor', type: 'ultrasonic' },
      { id: 'ir_sensor', name: 'IR Obstacle Sensor', icon: '🚨', desc: 'Infrared Proximity Module', type: 'ir_sensor' },
      { id: 'ldr', name: 'LDR Photoresistor', icon: '☀️', desc: 'Light Intensity Sensor', type: 'ldr' },
      { id: 'gyroscope', name: 'MPU6050 Gyro/Accel', icon: '📐', desc: '6-Axis Motion Sensor', type: 'gyro' }
    ]
  },
  {
    id: 'actuators',
    label: 'Actuators',
    icon: <Settings2 className="w-4 h-4 text-indigo-400" />,
    items: [
      { id: 'servo', name: 'SG90 Servo', icon: '🪛', desc: '0° to 180° Micro Servo Motor', type: 'servo' },
      { id: 'dc_motor', name: 'DC Gear Motor', icon: '🌀', desc: '3-6V Gearbox Motor', type: 'dc_motor' },
      { id: 'led', name: '5mm Red LED', icon: '🔴', desc: 'Diffused Red Diode', type: 'led' },
      { id: 'buzzer', name: 'Piezo Buzzer', icon: '🔔', desc: '5V Audio Alarm', type: 'buzzer' }
    ]
  },
  {
    id: 'connections',
    label: 'Connections',
    icon: <Plug className="w-4 h-4 text-rose-400" />,
    items: [
      { id: 'wire_vcc', name: 'Power Wire (5V)', icon: '🔴', desc: '5V Power Rail Jumper Wire', type: 'wire' },
      { id: 'wire_gnd', name: 'Ground Wire (GND)', icon: '🖤', desc: '0V Ground Reference Wire', type: 'wire' },
      { id: 'wire_signal', name: 'Digital/PWM Wire', icon: '🟡', desc: 'Control Signal Jumper Wire', type: 'wire' }
    ]
  }
];

interface WorkspaceSidebarProps {
  onAddComponentToSimulator: (type: string, name: string) => void;
  selectedComponent: string | null;
}

export const WorkspaceSidebar: React.FC<WorkspaceSidebarProps> = ({
  onAddComponentToSimulator,
  selectedComponent
}) => {
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({
    robots: true,
    electronics: true,
    sensors: true,
    actuators: true,
    connections: false
  });

  const toggleCategory = (id: string) => {
    setOpenCategories(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/90 dark:bg-slate-950/90 backdrop-blur-md border border-slate-800 rounded-2xl overflow-hidden shadow-xl text-xs">
      <div className="p-3 bg-slate-950/80 dark:bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
        <span className="font-bold text-slate-200 dark:text-slate-100 uppercase tracking-wider flex items-center gap-1.5 text-[11px]">
          <Bot className="w-4 h-4 text-cyan-400" /> Component Library
        </span>
        <span className="text-[10px] text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded font-mono">
          Drag / Click to Add
        </span>
      </div>

      <div className="flex-1 overflow-y-auto p-2 space-y-2 select-none">
        {SIDEBAR_CATEGORIES.map((cat) => {
          const isOpen = openCategories[cat.id];
          return (
            <div key={cat.id} className="rounded-xl bg-slate-950/40 dark:bg-slate-900/40 border border-slate-800/80 overflow-hidden">
              <button
                onClick={() => toggleCategory(cat.id)}
                className="w-full flex items-center justify-between p-2.5 hover:bg-slate-800/50 transition text-left"
              >
                <div className="flex items-center gap-2">
                  {cat.icon}
                  <span className="font-bold text-slate-200 dark:text-slate-200">{cat.label}</span>
                  <span className="text-[10px] text-slate-500 font-mono">({cat.items.length})</span>
                </div>
                {isOpen ? (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                )}
              </button>

              {isOpen && (
                <div className="p-1.5 space-y-1.5 border-t border-slate-800/60 bg-slate-950/60 dark:bg-slate-950/80">
                  {cat.items.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => onAddComponentToSimulator(item.type, item.name)}
                      className={`group flex items-center justify-between p-2 rounded-lg cursor-pointer transition border ${
                        selectedComponent === item.type
                          ? 'bg-cyan-950/80 border-cyan-500/80 text-cyan-300'
                          : 'bg-slate-900/60 hover:bg-slate-800 border-slate-800/80 hover:border-slate-700 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="text-base shrink-0">{item.icon}</span>
                        <div className="truncate">
                          <p className="font-semibold text-slate-200 dark:text-slate-200 truncate group-hover:text-white">
                            {item.name}
                          </p>
                          <p className="text-[10px] text-slate-400 dark:text-slate-400 truncate">
                            {item.desc}
                          </p>
                        </div>
                      </div>

                      <button
                        title="Add to 3D Simulator"
                        className="p-1 rounded bg-cyan-950/80 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 border border-cyan-800/60 opacity-0 group-hover:opacity-100 transition shrink-0 ml-1"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="p-2.5 bg-slate-950/80 border-t border-slate-800 text-[10px] text-slate-400 flex items-center gap-1.5">
        <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
        <span>Click any hardware component to inspect live telemetry in 3D workbench.</span>
      </div>
    </div>
  );
};
