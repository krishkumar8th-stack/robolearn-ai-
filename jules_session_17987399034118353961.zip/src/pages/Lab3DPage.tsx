import React, { useState } from 'react';
import { ThreeSimulatorCanvas } from '../components/simulator/ThreeSimulatorCanvas';
import { MonacoEditorPanel } from '../components/editor/MonacoEditorPanel';
import { WorkspaceSidebar } from '../components/workspace/WorkspaceSidebar';
import { WorkspaceAIPanel } from '../components/workspace/WorkspaceAIPanel';
import { useSimulation } from '../contexts/SimulationContext';
import {
  Box,
  Code,
  Terminal,
  Cpu,
  Zap,
  Info,
  Maximize2,
  SlidersHorizontal
} from 'lucide-react';

const PRESET_CODE_SNIPPETS: { [key: string]: { title: string; code: string; desc: string } } = {
  rover_avoidance: {
    title: 'Autonomous Obstacle Avoidance Rover',
    desc: 'Uses HC-SR04 sonar on servo turret to detect obstacles, brake, and turn away.',
    code: `// Autonomous Obstacle Avoidance Robot (Arduino + Sonar + L298N)
#include <Servo.h>

const int trigPin = 11;
const int echoPin = 12;
const int ledStatusPin = 13;
Servo sonarServo;

void setup() {
  Serial.begin(9600);
  pinMode(ledStatusPin, OUTPUT);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  
  sonarServo.attach(9);
  sonarServo.write(90); // Look straight ahead
  Serial.println("RoboLearn Rover Autonomous Navigation Online.");
}

void loop() {
  // Read distance from ultrasonic sonar
  long distance = readSonarDistance();
  Serial.print("Sonar Ping Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  if (distance < 20) {
    // Obstacle detected! Apply emergency brakes and warn
    digitalWrite(ledStatusPin, HIGH);
    robotStop();
    delay(500);

    // Turn away from obstacle
    robotTurnLeft();
    delay(800);
    
    // Stop and resume
    robotStop();
    digitalWrite(ledStatusPin, LOW);
  } else {
    // Path clear - cruise forward
    digitalWrite(ledStatusPin, LOW);
    robotForward();
    delay(1000);
  }
}

long readSonarDistance() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  
  long duration = pulseIn(echoPin, HIGH);
  long dist = duration * 0.034 / 2;
  return (dist == 0) ? 18 : dist;
}

void robotForward() {
  Serial.println("[ROVER] Moving forward at cruising speed");
}

void robotStop() {
  Serial.println("[ROVER] Applying brakes - Halted");
}

void robotTurnLeft() {
  Serial.println("[ROVER] Steering 90 degrees Left to evade collision");
}`
  },
  led_blink: {
    title: 'Precision LED Blinker with Serial Telemetry',
    desc: 'Configures digital pin 13 with current-limiting resistor and logs status.',
    code: `// Precision LED Blink with Serial Telemetry
const int ledPin = 13;

void setup() {
  Serial.begin(9600);
  pinMode(ledPin, OUTPUT);
  Serial.println("GPIO 13 configured as OUTPUT.");
}

void loop() {
  digitalWrite(ledPin, HIGH);
  Serial.println("[GPIO] Pin 13 HIGH (LED ON)");
  delay(1000);

  digitalWrite(ledPin, LOW);
  Serial.println("[GPIO] Pin 13 LOW (LED OFF)");
  delay(1000);
}`
  },
  servo_sweep: {
    title: 'SG90 Micro Servo 180° Sweep',
    desc: 'Sweeps micro servo horn back and forth between 0° and 180° smoothly.',
    code: `// SG90 Servo Angular Position Control
#include <Servo.h>

Servo myServo;

void setup() {
  Serial.begin(9600);
  myServo.attach(9);
  Serial.println("Servo attached to PWM Pin 9");
}

void loop() {
  Serial.println("[SERVO] Moving to 0 degrees");
  myServo.write(0);
  delay(800);

  Serial.println("[SERVO] Moving to 90 degrees (Center)");
  myServo.write(90);
  delay(800);

  Serial.println("[SERVO] Moving to 180 degrees");
  myServo.write(180);
  delay(800);
}`
  }
};

export const Lab3DPage: React.FC = () => {
  const [selectedSnippetKey, setSelectedSnippetKey] = useState('rover_avoidance');
  const [activeCode, setActiveCode] = useState(PRESET_CODE_SNIPPETS.rover_avoidance.code);
  const [addedComponents, setAddedComponents] = useState<string[]>([]);

  const { state, setSpeedMultiplier, selected3DComponent, setSelected3DComponent } = useSimulation();

  const handleSelectSnippet = (key: string) => {
    setSelectedSnippetKey(key);
    setActiveCode(PRESET_CODE_SNIPPETS[key].code);
  };

  const handleAddComponentToSimulator = (type: string, name: string) => {
    setSelected3DComponent(type);
    if (!addedComponents.includes(name)) {
      setAddedComponents(prev => [...prev, name]);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 p-3 sm:p-5 max-w-[1600px] mx-auto w-full transition-colors duration-200">
      {/* Workspace Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-cyan-100 dark:bg-cyan-950/80 border border-cyan-300 dark:border-cyan-800/60 text-cyan-600 dark:text-cyan-400">
              <Box className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                Robotics IDE Workspace & 3D Lab
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Integrated IDE Layout: Add components, control 3D physics, write firmware code, and debug with AI copilot.
              </p>
            </div>
          </div>
        </div>

        {/* Speed & Presets Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {Object.entries(PRESET_CODE_SNIPPETS).map(([key, snippet]) => (
              <button
                key={key}
                onClick={() => handleSelectSnippet(key)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition border ${
                  selectedSnippetKey === key
                    ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold shadow-md'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {snippet.title}
              </button>
            ))}
          </div>

          <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-1 text-xs">
            {[0.5, 1, 2].map((spd) => (
              <button
                key={spd}
                onClick={() => setSpeedMultiplier(spd)}
                className={`px-2.5 py-1 rounded-lg font-mono font-bold transition ${
                  state.speedMultiplier === spd ? 'bg-cyan-500 text-slate-950' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main IDE Workspace 3-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch mb-4">
        {/* LEFT COLUMN: Sidebar Component Palette */}
        <div className="lg:col-span-3 h-[560px]">
          <WorkspaceSidebar
            onAddComponentToSimulator={handleAddComponentToSimulator}
            selectedComponent={selected3DComponent}
          />
        </div>

        {/* CENTER COLUMN: 3D Three.js Simulator Canvas */}
        <div className="lg:col-span-6 flex flex-col gap-3">
          <div className="relative h-[480px]">
            <ThreeSimulatorCanvas heightClass="h-full" showToolbar={true} />
          </div>

          {/* Telemetry Hardware Quick Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-[10px] text-slate-400 font-mono uppercase font-bold">Board</span>
              <p className="font-bold text-cyan-600 dark:text-cyan-400 mt-0.5">Arduino Uno R3</p>
            </div>

            <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-[10px] text-slate-400 font-mono uppercase font-bold">LED Pin 13</span>
              <p className="font-bold text-slate-800 dark:text-white mt-0.5 flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${state.leds['13']?.on ? 'bg-rose-500 animate-pulse' : 'bg-slate-400 dark:bg-slate-600'}`} />
                {state.leds['13']?.on ? 'HIGH (ON)' : 'LOW (OFF)'}
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-[10px] text-slate-400 font-mono uppercase font-bold">Servo Angle</span>
              <p className="font-bold text-indigo-600 dark:text-indigo-400 mt-0.5 font-mono">
                {state.servos['servo_01']?.angle ?? 90}°
              </p>
            </div>

            <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-[10px] text-slate-400 font-mono uppercase font-bold">Sonar Ping</span>
              <p className="font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
                {state.obstacle.distanceToRobot} cm
              </p>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: AI Copilot, Debugger & Builder */}
        <div className="lg:col-span-3 h-[560px]">
          <WorkspaceAIPanel
            currentCode={activeCode}
            onApplyCode={(newCode) => setActiveCode(newCode)}
          />
        </div>
      </div>

      {/* BOTTOM PANEL: Monaco Code Editor & Serial Telemetry Console */}
      <div className="w-full">
        <MonacoEditorPanel
          key={selectedSnippetKey}
          initialCode={activeCode}
          language="cpp"
          targetBoard="Arduino Uno"
          height="450px"
        />
      </div>
    </div>
  );
};
